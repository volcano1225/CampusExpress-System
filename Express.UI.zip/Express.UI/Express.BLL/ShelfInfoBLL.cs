﻿using Express.DAL;
using Express.Model;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Express.BLL
{
    public class ShelfInfoBLL
    {
        ShelfInfoDAL dal = new ShelfInfoDAL();
        public DataTable GetList(string keyword) { return dal.GetAll(keyword); }
        public bool Add(ShelfInfo sh) { return dal.Add(sh); }
        public bool Update(ShelfInfo sh) { return dal.Update(sh); }
        public bool Delete(int id) { return dal.Delete(id); }
        public bool IncreaseRemainSpace(int shelfId)
        {
            string sql = "UPDATE ShelfInfo SET RemainSpace = RemainSpace + 1 WHERE ShelfId=@id";
            return DBHelper.ExecuteNonQuery(sql, new SqlParameter("@id", shelfId)) > 0;
        }
        public int GetSendLimit(int stuId)
        {
            string sql = "SELECT MaxSendNum FROM StudentInfo WHERE StuId=@id";
            return Convert.ToInt32(DBHelper.ExecuteScalar(sql, new SqlParameter("@id", stuId)));
        }

    }

}
