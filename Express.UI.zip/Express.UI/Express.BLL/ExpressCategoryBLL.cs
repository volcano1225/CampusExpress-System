﻿using System.Data;
using Express.Model;
using Express.DAL;

namespace Express.BLL
{
    public class ExpressCategoryBLL
    {
        ExpressCategoryDAL dal = new ExpressCategoryDAL();
        public DataTable GetList(string keyword) { return dal.GetAll(keyword); }
        public bool Add(ExpressCategory c) { return dal.Add(c); }
        public bool Update(ExpressCategory c) { return dal.Update(c); }
        public bool Delete(int id) { return dal.Delete(id); }
    }
}
