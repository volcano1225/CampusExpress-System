﻿using System.Data;
using Express.Model;
using Express.DAL;

namespace Express.BLL
{
    public class ExpressPackageBLL
    {
        ExpressPackageDAL dal = new ExpressPackageDAL();

        public DataTable GetList(string keyword) { return dal.GetAll(keyword); }
        public bool Add(ExpressPackage p) { return dal.Add(p); }
        public bool Update(ExpressPackage p) { return dal.Update(p); }
        public bool Delete(int id) { return dal.Delete(id); }

        public bool Pickup(int packageId)
        {
            // 调用DAL：UPDATE ExpressPackage SET IsPickUp=1, PickUpTime=GETDATE(), Status=2 WHERE PackageId=@id
            return dal.Pickup(packageId);
        }

        public bool UpdateFine(int packageId, decimal fine)
        {
            return dal.UpdateFine(packageId, fine);
        }
    }
}