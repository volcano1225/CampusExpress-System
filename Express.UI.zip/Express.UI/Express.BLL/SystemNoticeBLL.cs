﻿using System.Data;
using Express.Model;
using Express.DAL;

namespace Express.BLL
{
    public class SystemNoticeBLL
    {
        SystemNoticeDAL dal = new SystemNoticeDAL();
        public DataTable GetList(string keyword) { return dal.GetAll(keyword); }
        public DataTable GetShowList() { return dal.GetShowList(); }
        public bool Add(SystemNotice n) { return dal.Add(n); }
        public bool Update(SystemNotice n) { return dal.Update(n); }
        public bool Delete(int id) { return dal.Delete(id); }
    }
}

