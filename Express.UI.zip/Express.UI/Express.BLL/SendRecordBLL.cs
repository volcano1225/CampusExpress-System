﻿using Express.DAL;
using Express.Model;
using System;
using System.Data;
using System.Data.SqlClient;
using Express.Model;
using Express.DAL;

namespace Express.BLL
{
    public class SendRecordBLL

    {
        SendRecordDAL dal = new SendRecordDAL();
        ExpressPackageDAL packageDal = new ExpressPackageDAL();
        SendRecordDAL sendDal = new SendRecordDAL();
        public DataTable GetList(string keyword)
        {
            return dal.GetAll(keyword);
        }

        public bool Add(SendRecord sr)
        {
            return dal.Add(sr);
        }

        public bool MarkPay(int recId)
        {
            return dal.UpdatePay(recId);
        }
        public int GetTodaySendCount(int stuId)
        {
            string sql = "SELECT COUNT(*) FROM SendRecord WHERE StuId=@stuId AND CAST(SendTime AS DATE)=CAST(GETDATE() AS DATE)";
            return Convert.ToInt32(DBHelper.ExecuteScalar(sql, new SqlParameter("@stuId", stuId)));
        }

        public DataTable GetListByStudent(int stuId)
        {
            string sql = "SELECT * FROM SendRecord WHERE StuId=@stuId ORDER BY SendTime DESC";
            return DBHelper.ExecuteQuery(sql, new SqlParameter("@stuId", stuId));
        }
        public bool SendExpress(int stuId, ExpressPackage package, SendRecord record)
        {
            // 1. 先创建包裹记录，获取PackageId
            int packageId = packageDal.AddPackage(package);

            // 2. 把PackageId赋给寄件记录
            record.PackageId = packageId;
            record.StuId = stuId;

            // 3. 插入寄件记录
            return sendDal.Add(record);
        }
    }
}