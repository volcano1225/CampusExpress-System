﻿using System.Data;
using Express.Model;
using Express.DAL;

namespace Express.BLL
{
    public class StudentInfoBLL
    {
        StudentInfoDAL dal = new StudentInfoDAL();
        public DataTable GetList(string keyword) { return dal.GetAll(keyword); }
        public bool Add(StudentInfo s) { return dal.Add(s); }
        public bool Update(StudentInfo s) { return dal.Update(s); }
        public bool Delete(int id) { return dal.Delete(id); }
        public bool ResetPassword(int id, string pwd) { return dal.ResetPwd(id, pwd); }
        public DataTable Login(string user, string pwd) { return dal.GetByLogin(user, pwd); }
        public int GetSendLimit(int stuId)
        {
            return dal.GetSendLimit(stuId);
        }
    }
}

